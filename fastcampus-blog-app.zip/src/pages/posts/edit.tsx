import React from "react";
import PostForm from "components/PostForm";
import Header from "components/Header";

export default function Edit(){ 
    return (
        <>
            <Header />
            <PostForm />
        </>
    );
}