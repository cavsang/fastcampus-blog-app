import React from "react";

export default function Logout(){ 
    return <h1>Logout Page</h1>;
}